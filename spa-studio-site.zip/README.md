# SPA Studio

A static, mobile-friendly self-study app for Speaking Proficiency Assessment practice.

## Files

- `index.html` — the complete app
- `manifest.json` — lets supported phones treat the site like an app

## Hosting

This is a static website. Upload these files to GitHub Pages, Netlify, Vercel, or another static web host.

The site does not require a database or server.

## Important

Student progress is stored locally in the student's browser. Different students will have separate progress automatically.

The current version uses built-in exercises and browser speech recognition where supported. It does not send student answers to an AI service.
